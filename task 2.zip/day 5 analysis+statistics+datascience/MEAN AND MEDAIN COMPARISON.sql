--statistics and business interpretation
--mean and median IS MEAN BIGGER THEN MEDIAN
WITH SALESSTAT AS
(
select salesamount AS MEAN,
PERCENTILE_CONT(0.5)
WITHIN GROUP(ORDER BY SALESAMOUNT)
OVER() AS MEDIANSALES
from dw.factsales
WHERE SALESAMOUNT>0
)
SELECT AVG(MEAN) AS MEAN,MAX(MEDIANSALES) AS MEDAINSALES FROM SALESSTAT

--IF MEAN IS BIGGER THEN MEDIAN THEN A LARGE TRANSACTION PULL UP
For SalesAmount:

Mean > Median → the sales distribution is likely right-skewed.

Business interpretation:

A relatively small number of large-value transactions are pulling the mean upward.
Therefore, the median is a better representation of a typical transaction than the mean alone.
Your AOV of ~883.90 should therefore be interpreted carefully; it does not necessarily represent the typical transaction value.