--MEASURE THE DISTRIBUTION SKEWNESS
--CALCULATE  SKEWNESS FROM THESE VALUES
SELECT 
COUNT(*) AS N,
AVG(SALESAMOUNT) AS MEANSALES,
STDEV(SALESAMOUNT) AS STDSALES
FROM DW.FACTSALES
WHERE SALESAMOUNT>0
/*
N = 1,659,931 positive sales transactions
Mean = 25.03
Standard deviation = 182.09

Notice the huge gap: 25 average vs 182 standard deviation.
That suggests very high variability in transaction amounts, 
which is consistent with the mean/median finding you already observed.
*/

--SKEWNESS IS THIS SALESAMOUNT DISTRIBUTION TOWARDS USUALLY LARGE TRANSACTION?

SELECT 
AVG(
POWER(SALESAMOUNT-STATS.MEANSALES,3)
/POWER(STATS.STDSALES,3) )AS SKEWNESS
FROM DW.factsales
CROSS JOIN
(
SELECT 
COUNT(*) AS N,
AVG(SALESAMOUNT) AS MEANSALES,
STDEV(SALESAMOUNT) AS STDSALES
FROM DW.FACTSALES
WHERE SALESAMOUNT>0
)STATS
WHERE SALESAMOUNT>0
 
Skewness measures asymmetry of the distribution.

Think of it like this:

Skewness	Meaning
≈ 0	Roughly symmetric
> 0	Right-skewed
< 0	Left-skewed

For your retail data,
we're particularly interested in whether a relatively 
small number of large transactions create a long right tail.

Business question

Is the skewness positive or negative,
and what does that mean for the distribution of retail sales?
