--OUTLIER INVESTIGATION
--INVESTIGATE THE EXTREME TRANSACTION
SELECT TOP 20
INVOICENO,
CUSTOMERKEY,
PRODUCTKEY,
QUANTITY,
SALESAMOUNT
FROM DW.FACTSALES
WHERE SALESAMOUNT>42.325
ORDER BY SALESAMOUNT DESC
/*
Pattern 1 — Extreme quantity

581483

Quantity = 80,995
SalesAmount = 168,469.60

541431

Quantity = 74,215
SalesAmount = 77,183.60

These are extreme mainly because of very large quantities.

Pattern 2 — Repeated high-value product lines

Invoice 556444 appears across several products:

Quantity = 60 each
SalesAmount = 38,970 each

That suggests the extreme value isn't necessarily a random error; it may represent a large business order.

Pattern 3 — Very high-value individual items

For example:

Quantity = 1
SalesAmount = 10,953.50
Quantity = 1
SalesAmount = 10,468.80
Quantity = 1
SalesAmount = 8,985.60

These are different from the first two:
high value comes from price/value per unit rather than huge quantity.

So you've learned an important analytical lesson:

An outlier tells you "this observation is unusual.
" It does not tell you "this observation is wrong."

You should therefore keep these records unless
business/data-quality investigation proves they are invalid.
*/