--CORRELATION
--DOES QUANTITY HAVE A RELATIONSHIP WITH SALESAMOUNT?

SELECT
(
    CAST(COUNT(*) AS FLOAT) * SUM(CAST(QUANTITY AS FLOAT) * SALESAMOUNT)
    - SUM(CAST(QUANTITY AS FLOAT)) * SUM(SALESAMOUNT)
)
/
NULLIF(
    SQRT(
        (
            CAST(COUNT(*) AS FLOAT) * 
            SUM(CAST(QUANTITY AS FLOAT) * QUANTITY)
            - POWER(SUM(CAST(QUANTITY AS FLOAT)), 2)
        )
        *
        (
            CAST(COUNT(*) AS FLOAT) *
            SUM(SALESAMOUNT * SALESAMOUNT)
            - POWER(SUM(SALESAMOUNT), 2)
        )
    ),
    0
) AS QUANTITY_SALES_CORRELATION
FROM DW.FactSales
WHERE SALESAMOUNT > 0;

/*
You have now completed the Statistics checklist
Topic	Status	Your finding
Mean	Done	25.03
Median	Done	12.75
Mean vs Median	Done	Mean > Median
Distribution	Done	Strong right tail
Skewness	Done	Strong positive skew
Standard deviation	Done	182.09
Percentiles	Done	P25–P99 calculated
IQR	Done	14.95
Outliers	Done	Investigated rather than blindly removed
Correlation	Done	0.7088 positive
*/