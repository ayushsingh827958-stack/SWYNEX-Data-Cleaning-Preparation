use retail_sales
--business conclusion
--5 business retail finding 

--customer
select * from dw.CustomerRFM
/*
--finding: customer value and
 customer activity are not necessarily aligned;
 some customers have generated substantial revenue
 but are currently inactive.

 --evidence: customer 2 has monetary=12428.66
 and frequency=8 but a very high recency value of 40,885 days,
 while customer 4 has monetary =7560.31,
 frequency=6 and a much lower recency of 181 days.

 business meaning:historical high-value customers are not automatically currently
 active customers.the business should distinguish between valuable active customers and 
 valuable but inactive customers when planning retention or reactivation activities.
 */
 
 --product analysis
 /*
 finding:product revenue is generated through different sales patterns:
 some products generate high revenue through large sales volumes,while others generate
 relatively high revenue despite selling fewer units.
 
 evidence:doormat union jack and guns and roses generated 3.433.69 from 2869 unit,
 while 3 stripey micefeltcraft generated 4800.79 from 1201 units.other products in the analysis
 generated comparatively high revenue with much smaller quantities, 
 such as purple flock dinner candles with 51.90 from only 4 units.

 Business meaning: product performance should not be evaluated using quantity
 alone.high_volume products and higher-value products can contribute to revenue indifferent ways,
 so the retailer should analyze both sales volume and revenue when making product decisions.
 */
