--product analytics

--top products by revenue
select * from dw.ProductSales
select  *,
rank() over(order by total_sales desc) from dw.ProductSales
--top products by quantity
select  *,
rank() over(order by quantity_total desc) from dw.ProductSales

--compare revenue vs quantity
with product_state as
(
select
description,
total_sales,
quantity_total
from dw.ProductSales
),
thresholds
as
(
select
PERCENTILE_CONT(0.5) ---? start
within group(order by total_sales)
over()as revenue_median,
PERCENTILE_CONT(0.5)
within group(order by quantity_total)
over() as quantity_median ---?stop
from dw.ProductSales

)
select distinct
p.description,
p.total_sales,
p.quantity_total,
 case when p.total_sales>=t.revenue_median
 and p.quantity_total>=t.quantity_median
 then ' high_revenue_quantity'

 when p.total_sales<t.revenue_median
 and p.quantity_total>=t.quantity_median
 then 'low_revenue_high_quantity'

 when p.total_sales>=t.revenue_median
 and p.quantity_total<t.quantity_median
 then 'high_revenue_low_quantity'

 else' high_revenue_low_quantity'
 end
 as product_stat
 from product_state p
 cross join thresholds t;---?
--investigate
--high quantity+highrevenue---> major products check	582533.32	check	412861
--high quantity+low revenue-->high_volumne
--lowquantity+high revenue--->low volume?high value product
--low quantity+low revenue-->lower commercialcontribution

/*
  DOORMAT UNION JACK GUNS AND ROSES	3433.69	2869	 high_revenue_quantity
 3 STRIPEY MICE FELTCRAFT	4800.79	1201	 high_revenue_quantity
 4 PURPLE FLOCK DINNER CANDLES	51.9	4	 high_revenue_low_quantity
 50'S CHRISTMAS GIFT BAG LARGE	1128.93	351	 high_revenue_low_quantity
 ANIMAL STICKERS	46.8	24	 high_revenue_low_quantity
 BLACK PIRATE TREASURE CHEST	5689.8	6791	 high_revenue_quantity
 BROWN  PIRATE TREASURE CHEST 	9181.72	5136	 high_revenue_quantity
 CAMPHOR WOOD PORTOBELLO MUSHROOM	578.75	463	 high_revenue_low_quantity
 CHERRY BLOSSOM  DECORATIVE FLASK	72.25	85	 high_revenue_low_quantity
 */