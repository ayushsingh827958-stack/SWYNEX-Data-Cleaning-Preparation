use RETAIL_SALES
--calculate thebusiness kpi        8:09 am
--total revenue
--total order
--total customer
--total product
--average order value
select sum(salesamount) as total_revenue,
count(distinct Invoiceno) as unique_order,
count(distinct customerkey) as total_customer,
count(distinct productkey) as total_product,
sum(salesamount)/count(distinct Invoiceno) as average_order_value
from dw.factsales
/*
total_revenue	unique_order	total_customer	total_product	average_order_value
39665824.8790	44876	5955	8275	883.898406
*/
select * from dw.CountrySales
/*
countryname	total_sales	total_order	total_customer	quantity_total

*/
select * from dw.Customersales
--customerkey	total_product	total_sales	total_order	quantity_total
select * from dw.datebysale
-- year	month  total_sales	total_order	total_customer	quantity_total

select * from dw.ProductSales
--description	total_product	total_sales	total_order	total_customer	quantity_total
  

--Who are the highest-revenue customers?
select * from dw.Customersales 
order by total_sales desc
/*
customerkey	total_product	total_sales	total_order	quantity_total
2536	2417	1471682.87	2417	441659
5539	7583	1179368.06	7583	717852
1679	8506	714334.86	8506	333257
2618	23764	615577.67	23764	284551
*/
--How concentrated is revenue among customers?
select * from dw.dimcustomer c
join dw.factsales f on c.customerkey=f.customerkey
where salesamount=0
--157 person  actual revenue 0
select count(distinct c.customerkey) from dw.dimcustomer c
join dw.factsales f on c.customerkey=f.customerkey
where salesamount>0
-- 5891 have concentrated purchase

--Which customers have many orders?
select count(distinct invoiceno) from dw.factsales
/*
customerkey	total_product	total_sales	total_order	quantity_total
2739	24885	150922.37	24885	73983
2618	23764	615577.67	23764	284551
339	14005	102205.01	14005	72014
3512	13150	65581.74	13150	30724
*/
--Do high-order-frequency customers also generate high revenue?
select * from dw.Customersales
order by total_sales desc,total_order desc

--Is there a difference between high-value customers and frequent customers?
select customerkey from dw.Customersales
group by customerkey
order by high desc

---customer most recent purchase date
select d.year,d.monthname,f.salesamount,f.customerkey from dw.datebysale d
join dw.factsales f
on d.datekey=f.datekey
order by year desc

---RFM recency frequency monetary
select f.customerkey,
count(distinct f.invoiceno) as frequency,
sum(f.salesamount) as monetary,
max(d.fulldate) as lastpurcahsedate,
datediff(
day,max(d.fulldate),
(select max(fulldate)from dw.dimdate d)
)as recency
from dw.dimdate d
join dw.factsales f on d.datekey=f.datekey
where f.salesamount>0
group by f.customerkey
order by monetary desc
/*
This gives:

recent customers → R5
less recent customers → lower R score

For Frequency and Monetary:

more orders → F5
more revenue → M5
*/
---RFM score
with rfm
as
(select f.customerkey,
count(distinct f.invoiceno) as frequency,
sum(f.salesamount) as monetary,
max(d.fulldate) as lastpurcahsedate,
datediff(
day,max(d.fulldate),
(select max(fulldate)from dw.dimdate d)
)as recency
from dw.dimdate d
join dw.factsales f on d.datekey=f.datekey
where f.salesamount>0
group by f.customerkey

),rfm_score
as
(
select *,ntile(5) over(order by recency desc) as r_score,
ntile(5) over(order by frequency desc) as f_score,
ntile(5) over(order by monetary desc) as m_score
from rfm
)
select * from rfm_score
order by monetary desc
end
--create table customer rfm
CREATE TABLE dw.CustomerRFM
(
    CustomerKey INT PRIMARY KEY,
    Recency INT,
    Frequency INT,
    Monetary DECIMAL(18,2),
    R_Score INT,
    F_Score INT,
    M_Score INT,
    RFM_Total INT,
    RFM_Code VARCHAR(3),
    UpdatedAt DATETIME DEFAULT GETDATE()
);
--store them into procedure
create procedure rfm_score_customer
as
begin
set nocount on; ---?
--remove previous rfm results
truncate table dw.customerrfm;

with rfm as
(
select f.customerkey,
--recency
datediff(
day,
max(d.fulldate),
(select max(fulldate)from dw.dimdate d
where d.fulldate is not null
)
)as recency,
--frequency
count(distinct f.invoiceno) as frequency,
--monetary
sum(f.salesamount) as monetary
--max(d.fulldate) as lastpurcahsedate,
from dw.factsales f
join dw.dimdate d on f.datekey=d.datekey
where f.salesamount>0
group by f.customerkey

),rfm_score
as
(
select *,ntile(5) over(order by recency desc) as r_score,
ntile(5) over(order by frequency desc) as f_score,
ntile(5) over(order by monetary desc) as m_score
from rfm
)
insert into dw.customerrfm
( CustomerKey,
    Recency ,
    Frequency ,
    Monetary ,
    R_Score ,
    F_Score ,
    M_Score ,
    RFM_Total ,
    RFM_Code 
    )
select 
customerkey,
recency,
frequency,
monetary,
r_score,
f_score,
m_score,
R_Score + F_Score + M_Score AS RFM_Total,

        CONCAT(
            R_Score,
            F_Score,
            M_Score
        ) AS RFM_Code
        from rfm_score

end
exec rfm_score_customer

select * from dw.CustomerRFM