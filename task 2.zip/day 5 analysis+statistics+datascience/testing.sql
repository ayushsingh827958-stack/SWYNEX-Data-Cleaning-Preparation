SELECT
    COLUMN_NAME,
    DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'dw'
  AND TABLE_NAME IN ('FactSales', 'DimDate');

  SELECT TOP 5 *
FROM dw.DimDate;
datekey	fulldate	year	quarter	month	MonthName	day	dayname	weekofyear
0	1900-01-01	0	0	0	Unknown	0	Unknown	0
20090112	2009-01-12	2009	1	1	January	12	Monday	3
20090113	2009-01-13	2009	1	1	January	13	Tuesday	3
20090114	2009-01-14	2009	1	1	January	14	Wednesday	3

select top 5 * from dw.factsales
saleskey	datekey	customerkey	countrykey	productkey	invoiceno	quantity	unitprice	salesamount
1	20110803	3380	11	2881	545998	6	2.9500	17.7000
2	20110803	3380	11	2882	545998	6	2.9500	17.7000
3	20110803	3380	11	2888	545998	6	2.9500	17.7000